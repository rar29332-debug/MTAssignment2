package com.example.mlkitapp;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MLKitResultAdapter extends BaseAdapter {

    Context context;
    ArrayList<MLKitResult> results;

    public MLKitResultAdapter(Context context, ArrayList<MLKitResult> results) {
        this.context = context;
        this.results = results;
    }

    @Override
    public int getCount() {
        return results.size();
    }

    @Override
    public Object getItem(int position) {
        return results.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.row_item, parent, false);
        }

        ImageView rowImage = convertView.findViewById(R.id.rowImage);
        TextView rowReader = convertView.findViewById(R.id.rowReader);
        TextView rowText = convertView.findViewById(R.id.rowText);

        MLKitResult item = results.get(position);

        rowReader.setText(item.reader);
        rowText.setText(item.text);

        if (item.imageUri != null) {
            rowImage.setImageURI(Uri.parse(item.imageUri));
        }

        return convertView;
    }
}