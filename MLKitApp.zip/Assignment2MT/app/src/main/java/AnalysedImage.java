public class AnalysedImage {
    public String id;
    public String reader;
    public String text;
    public String imagePath;
    public String filename;

    public AnalysedImage() {
    }

    public AnalysedImage(String id, String reader, String text, String imagePath, String filename) {
        this.id = id;
        this.reader = reader;
        this.text = text;
        this.imagePath = imagePath;
        this.filename = filename;
    }
}
