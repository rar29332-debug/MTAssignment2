package com.example.mlkitapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DetailActivity extends AppCompatActivity {

    TextView txtDetailReader, txtDetailResult;
    ImageView imgDetailSelected;
    Button btnDetailEdit, btnDetailDelete, btnDetailCancel;

    String filename;
    String reader;
    String text;
    String imageUri;

    DatabaseReference dbRef;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtDetailReader = findViewById(R.id.txtDetailReader);
        txtDetailResult = findViewById(R.id.txtDetailResult);
        imgDetailSelected = findViewById(R.id.imgDetailSelected);

        btnDetailEdit = findViewById(R.id.btnDetailEdit);
        btnDetailDelete = findViewById(R.id.btnDetailDelete);
        btnDetailCancel = findViewById(R.id.btnDetailCancel);

        filename = getIntent().getStringExtra("filename");
        reader = getIntent().getStringExtra("reader");
        text = getIntent().getStringExtra("text");
        imageUri = getIntent().getStringExtra("imageUri");

        txtDetailReader.setText(reader);
        txtDetailResult.setText(text);

        if (imageUri != null) {
            imgDetailSelected.setImageURI(Uri.parse(imageUri));
        }

        dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        btnDetailEdit.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, EditActivity.class);
            intent.putExtra("filename", filename);
            intent.putExtra("reader", reader);
            intent.putExtra("result", text);
            intent.putExtra("imageUri", imageUri);
            startActivity(intent);
            finish();
        });

        btnDetailDelete.setOnClickListener(v -> {
            if (filename != null) {
                dbRef.child(filename).removeValue()
                        .addOnSuccessListener(unused -> {
                            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(DetailActivity.this, ListActivity.class);
                            startActivity(intent);
                            finish();
                        })
                        .addOnFailureListener(e ->
                                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                        );
            }
        });

        btnDetailCancel.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, ListActivity.class);
            startActivity(intent);
            finish();
        });
    }
}