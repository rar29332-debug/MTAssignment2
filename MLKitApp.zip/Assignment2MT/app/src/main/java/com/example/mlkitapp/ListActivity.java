package com.example.mlkitapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ChildEventListener;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    ListView listAnalysedImages;
    Button btnAddNew;

    ArrayList<MLKitResult> mlKitResults;
    MLKitResultAdapter adapter;

    DatabaseReference dbRef;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listAnalysedImages = findViewById(R.id.listAnalysedImages);
        btnAddNew = findViewById(R.id.btnAddNew);

        mlKitResults = new ArrayList<>();
        adapter = new MLKitResultAdapter(this, mlKitResults);
        listAnalysedImages.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        loadDataFromFirebase();

        btnAddNew.setOnClickListener(v -> {
            Intent intent = new Intent(ListActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        listAnalysedImages.setOnItemClickListener((parent, view, position, id) -> {
            MLKitResult selectedItem = mlKitResults.get(position);

            Intent intent = new Intent(ListActivity.this, DetailActivity.class);
            intent.putExtra("filename", selectedItem.filename);
            intent.putExtra("reader", selectedItem.reader);
            intent.putExtra("text", selectedItem.text);
            intent.putExtra("imageUri", selectedItem.imageUri);

            startActivity(intent);
        });
    }

    private void loadDataFromFirebase() {
        mlKitResults.clear();
        adapter.notifyDataSetChanged();

        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {
                MLKitResult item = snapshot.getValue(MLKitResult.class);

                if (item != null) {
                    mlKitResults.add(item);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {
                refreshList();
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                refreshList();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void refreshList() {
        Intent intent = new Intent(ListActivity.this, ListActivity.class);
        startActivity(intent);
        finish();
    }
}