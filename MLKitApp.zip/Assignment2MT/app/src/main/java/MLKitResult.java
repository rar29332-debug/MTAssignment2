package com.example.mlkitapp;

public class MLKitResult {

    public String filename;
    public String reader;
    public String text;
    public String imageUri;

    public MLKitResult() {
    }

    public MLKitResult(String filename, String reader, String text, String imageUri) {
        this.filename = filename;
        this.reader = reader;
        this.text = text;
        this.imageUri = imageUri;
    }

    @Override
    public String toString() {
        return reader + "\n" + text;
    }
}