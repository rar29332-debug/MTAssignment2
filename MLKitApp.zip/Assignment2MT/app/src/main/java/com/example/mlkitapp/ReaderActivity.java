package com.example.mlkitapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class ReaderActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;

    TextView txtReaderTitle, txtResult;
    ImageView imgSelected;
    Button btnOpenCamera, btnLoadImage, btnEditResult;

    private Uri imageFileUri;
    private String reader;
    private String finalResult = "";

    ActivityResultLauncher<Intent> activityResultLauncher;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reader);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtReaderTitle = findViewById(R.id.txtReaderTitle);
        txtResult = findViewById(R.id.txtResult);
        imgSelected = findViewById(R.id.imgSelected);

        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        btnLoadImage = findViewById(R.id.btnLoadImage);
        btnEditResult = findViewById(R.id.btnEditResult);

        btnEditResult.setVisibility(View.GONE);

        reader = getIntent().getStringExtra("reader");

        if (reader == null) {
            reader = "Barcode Reader";
        }

        txtReaderTitle.setText(reader);

        if ("Barcode Reader".equals(reader)) {
            imgSelected.setImageResource(R.mipmap.ic_launcher_barcode);
        } else if ("Content Reader".equals(reader)) {
            imgSelected.setImageResource(R.mipmap.ic_launcher_content);
        } else if ("Text Reader".equals(reader)) {
            imgSelected.setImageResource(R.mipmap.ic_launcher_text);
        }

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {

                        if (result.getData() != null && result.getData().getData() != null) {
                            imageFileUri = result.getData().getData();
                        }

                        if (imageFileUri != null) {
                            imgSelected.setImageURI(imageFileUri);
                            txtResult.setText("Processing image...");
                            btnEditResult.setVisibility(View.GONE);

                            try {
                                InputImage image = InputImage.fromFilePath(this, imageFileUri);
                                processImageBasedOnReader(image);
                            } catch (IOException e) {
                                txtResult.setText("Error loading image.");
                                Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
        );

        btnOpenCamera.setOnClickListener(v -> openCamera());

        btnLoadImage.setOnClickListener(v -> loadImage());

        btnEditResult.setOnClickListener(v -> {
            Intent intent = new Intent(ReaderActivity.this, EditActivity.class);
            intent.putExtra("reader", reader);
            intent.putExtra("result", finalResult);
            intent.putExtra("imageUri", imageFileUri.toString());
            startActivity(intent);
        });
    }

    private void processImageBasedOnReader(InputImage image) {
        if ("Barcode Reader".equals(reader)) {
            processImageFromBarcodeReader(image);
        } else if ("Content Reader".equals(reader)) {
            processImageFromContentReader(image);
        } else if ("Text Reader".equals(reader)) {
            processImageFromTextReader(image);
        }
    }

    private void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options =
                new BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                        .build();

        BarcodeScanner scanner = BarcodeScanning.getClient(options);

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    StringBuilder resultText = new StringBuilder();
                    resultText.append("Detected barcode:\n");

                    for (Barcode barcode : barcodes) {
                        if (barcode.getRawValue() != null) {
                            resultText.append(barcode.getRawValue()).append("\n");
                        }
                    }

                    if (barcodes.isEmpty()) {
                        resultText.append("Barcode not found.");
                    }

                    finalResult = resultText.toString();
                    txtResult.setText(finalResult);
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    txtResult.setText("Failed to detect barcode.");
                    btnEditResult.setVisibility(View.GONE);
                });
    }

    private void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);

        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    StringBuilder resultText = new StringBuilder();
                    resultText.append("Recognised image content:\n");

                    int count = 1;

                    for (ImageLabel label : labels) {
                        resultText.append(count)
                                .append(". ")
                                .append(label.getText())
                                .append(" (")
                                .append(String.format("%.2f", label.getConfidence() * 100))
                                .append("% confidence)")
                                .append("\n");
                        count++;
                    }

                    if (labels.isEmpty()) {
                        resultText.append("No image content recognised.");
                    }

                    finalResult = resultText.toString();
                    txtResult.setText(finalResult);
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    txtResult.setText("Failed to recognise image content.");
                    btnEditResult.setVisibility(View.GONE);
                });
    }

    private void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer =
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    String text = visionText.getText();

                    if (text == null || text.trim().isEmpty()) {
                        finalResult = "Extracted text:\nNo text found.";
                    } else {
                        finalResult = "Extracted text:\n" + text;
                    }

                    txtResult.setText(finalResult);
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    txtResult.setText("Failed to extract text.");
                    btnEditResult.setVisibility(View.GONE);
                });
    }

    private boolean checkPermission() {
        boolean grantCamera = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED;

        if (!grantCamera) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_PERMISSION
            );
        }

        return grantCamera;
    }

    private void openCamera() {
        if (!checkPermission()) {
            return;
        }

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues()
        );

        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);

        activityResultLauncher.launch(takePhotoIntent);
    }

    private void loadImage() {
        Intent galleryIntent = new Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        );

        activityResultLauncher.launch(galleryIntent);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Camera permission is required", Toast.LENGTH_SHORT).show();
            }
        }
    }
}