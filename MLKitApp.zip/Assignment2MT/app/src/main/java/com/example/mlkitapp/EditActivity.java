package com.example.mlkitapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class EditActivity extends AppCompatActivity {

    TextView txtEditReaderTitle;
    EditText editResultText;
    ImageView imgEditSelected;
    Button btnSaveResult;

    String reader;
    String result;
    String imageUriString;
    String filename;
    String itemKey;
    Uri imageUri;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtEditReaderTitle = findViewById(R.id.txtEditReaderTitle);
        editResultText = findViewById(R.id.editResultText);
        imgEditSelected = findViewById(R.id.imgEditSelected);
        btnSaveResult = findViewById(R.id.btnSaveResult);

        reader = getIntent().getStringExtra("reader");
        result = getIntent().getStringExtra("result");
        imageUriString = getIntent().getStringExtra("imageUri");
        filename = getIntent().getStringExtra("filename");
        itemKey = getIntent().getStringExtra("itemKey");

        if (reader == null) reader = "Reader";
        if (result == null) result = "";
        if (filename == null) {
            filename = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
        }

        txtEditReaderTitle.setText(reader);
        editResultText.setText(result);

        if (imageUriString != null) {
            imageUri = Uri.parse(imageUriString);
            imgEditSelected.setImageURI(imageUri);
        }

        btnSaveResult.setOnClickListener(v -> saveToFirebase());
    }

    private void saveToFirebase() {
        String editedText = editResultText.getText().toString();

        DatabaseReference dbRef = FirebaseDatabase
                .getInstance()
                .getReference("Storage");

        HashMap<String, String> data = new HashMap<>();
        data.put("filename", filename);
        data.put("reader", reader);
        data.put("text", editedText);
        data.put("imageUri", imageUriString);

        dbRef.child(filename).setValue(data)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Saved to Firebase", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }
}